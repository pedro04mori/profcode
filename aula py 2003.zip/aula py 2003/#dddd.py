#dddd
nome = input("Coloque seu nome:")
media = float(input("Insira sua media:"))
frequencia = float(input("coloque sua frequencia:"))

if frequencia < 75:
    print("REPROVADO por falta ", nome)
elif media<6:
    print("o aluno ta reprovado por nota")
else: 
    print("aprovado") 
    
    
