
S= 255.50
D = 305.50
T = 360.50
diaria = (input("escolha sua diaria:"))
quantidade = int(input("quantas diarias?:"))

if diaria == "s" or diaria == "S":
    print("valor a pagar R$ %.2f"%(quantidade*255.50))
    
elif diaria == "D" or diaria == "d": 
    print("valor a pagar R$ %.2f"%(quantidade*305.50))
    
elif diaria == "T" or diaria == "t":   
    print("valor a pagar R$ %.2f"%(quantidade*360.50))
else :
    print("tipo de diaria invalido")
    
    






