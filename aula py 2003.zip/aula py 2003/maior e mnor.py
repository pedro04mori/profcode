n1= int(input("inisira o primeiro numero"))
n2= int(input("inisira o segundo numero"))
n3= int(input("inisira o terceiro numero"))

if n1 > n2 and n1> n3:
    print(n1, "é o maior número")
elif n2 > n1 and n2> n3:
    print(n2, "é o maior numero")
elif n3> n1 and n3> n2:
    print(n3, "é o maior numero")
else:print("os numero sao iguais")
    