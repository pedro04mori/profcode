print('bom dia')
nome = input('informe o nome do atelta:')
idade = int(input("informe a idade:"))
altura = float(input("coloque a altura:"))
sexo = input("informe seu sexo:")


if idade >=18 and altura >= 1.70 :
    print (nome, " Voce pode competir")
else : 
    print(nome,"voce nao pode competir coma mais feijao")
    if idade >=18:
        if altura >= 1.70:
            print(nome, "voce pode competir")
        else:
          print("voce nao pode competir")
    else: print(nome, "voce nao pode competir ")   
     
        
    
    
    
    
    

    